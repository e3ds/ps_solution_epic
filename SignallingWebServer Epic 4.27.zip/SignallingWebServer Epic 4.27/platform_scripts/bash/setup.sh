#!/bin/bash
pushd "$( dirname "${BASH_SOURCE[0]}" )"
pushd ../..
npm install
popd
popd
